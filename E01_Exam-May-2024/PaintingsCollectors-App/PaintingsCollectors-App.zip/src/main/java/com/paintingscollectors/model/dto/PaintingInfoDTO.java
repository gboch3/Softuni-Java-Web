package com.paintingscollectors.model.dto;



public class PaintingInfoDTO {
    //TODO

}
